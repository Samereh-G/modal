import React, { useState } from "react";
import "./App.css";
import Modal from "./components/Modal";

function App() {
  const [isOpen, setIsOpen] = useState(false);

  const handleOpenModal = () => {
    setIsOpen(true);
  };

  const handleCloseModal = () => {
    setIsOpen(false);
  };

  // a && b && c

  return (
    <div>
      just for testing
      <button onClick={handleOpenModal}>Open Modal</button>
      {isOpen && <Modal onClose={handleCloseModal} />}
    </div>
  );
}

export default App;
