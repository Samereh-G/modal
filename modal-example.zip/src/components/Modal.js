import React from "react";
import "./Modal.css";

export default function Modal({ onClose }) {
  return (
    <div className='modal'>
      <div className='modal__paper'>
        <div onClick={onClose}>X</div>
      </div>
    </div>
  );
}
